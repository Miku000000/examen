﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ic_tienda_presentacion.Migrations
{
    public partial class usersalt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "Security",
                table: "app_usuarios",
                keyColumn: "id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                schema: "Security",
                table: "app_usuarios",
                keyColumn: "id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                schema: "Security",
                table: "app_usuarios",
                keyColumn: "id",
                keyValue: 3);

            migrationBuilder.AddColumn<string>(
                name: "salt",
                schema: "Security",
                table: "app_usuarios",
                type: "TEXT",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "salt",
                schema: "Security",
                table: "app_usuarios");

            migrationBuilder.InsertData(
                schema: "Security",
                table: "app_usuarios",
                columns: new[] { "id", "clave", "correo", "estado", "id_persona", "id_rol" },
                values: new object[] { 1, "123456", "admin@admin.com", true, 1, 1 });

            migrationBuilder.InsertData(
                schema: "Security",
                table: "app_usuarios",
                columns: new[] { "id", "clave", "correo", "estado", "id_persona", "id_rol" },
                values: new object[] { 2, "123456", "user1@user.com", true, 2, 2 });

            migrationBuilder.InsertData(
                schema: "Security",
                table: "app_usuarios",
                columns: new[] { "id", "clave", "correo", "estado", "id_persona", "id_rol" },
                values: new object[] { 3, "123456", "user2@user.com", true, 3, 3 });
        }
    }
}
