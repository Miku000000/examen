# ic-tienda


## Construir

dotnet build

## Ejecutar

dotnet run --project=ic_tienda/ic_tienda_presentacion.csproj

## publicar

dotnet publish --project=ic_tienda/ic_tienda_presentacion.csproj


## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

# migraciones

## PM
Add-Migration initial
Update-Database

## Dotnet

dotnet ef migrations add InitialCreate
dotnet ef database update
