using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ic_tienda_bussines.Store.models
{
    public class Category
    {
        public int Id { get; set; }
        public int? CategoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool State { get; set; }
    }

    public class CategoryBody
    {
        public int? CategoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public static implicit operator Category(CategoryBody rb)
        {
            if (rb == null) return null;
            return new Category
            {
                Id = 0,
                Name = rb.Name,
                CategoryId = rb.CategoryId,
                Description = rb.Description
            };
        }
    }

    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly DbContext _context; // Cambia DbContext por tu contexto específico.

        public CategoriesController(DbContext context)
        {
            _context = context;
        }

        // GET: api/categories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Category>>> GetCategories()
        {
            return await _context.Set<Category>().ToListAsync();
        }

        // POST: api/categories
        [HttpPost]
        public async Task<ActionResult<Category>> CreateCategory(CategoryBody categoryBody)
        {
            var category = (Category)categoryBody;
            _context.Set<Category>().Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCategories), new { id = category.Id }, category);
        }

        // DELETE: api/categories/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = await _context.Set<Category>().FindAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            _context.Set<Category>().Remove(category);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
