﻿using ic_tienda_bussines.Auth.models;
using ic_tienda_bussines.Auth.services;

namespace ic_tienda_data.Auth.services
{
    public class AppUserDbImpl : IAppUserService
    {
        public AppUser Create(AppUser entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<AppUser> GetAll()
        {
            throw new NotImplementedException();
        }

        public AppUser? GetById(int id)
        {
            throw new NotImplementedException();
        }

        public void Update(int id, AppUser entity)
        {
            throw new NotImplementedException();
        }
    }
}
