using ic_tienda_bussines.Auth.models;

namespace ic_tienda_bussines.Auth.services
{
    public interface IAuthenticationService
    {
        public void Register(AppUserRegister body);
    }
}
