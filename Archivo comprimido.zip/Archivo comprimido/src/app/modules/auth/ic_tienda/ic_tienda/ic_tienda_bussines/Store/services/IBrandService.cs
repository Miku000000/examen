using ic_tienda_bussines.Store.models;
using ic_tienda_bussines.Utils;

namespace ic_tienda_bussines.Store.services
{
    public interface IBrandService: ICrud<Brand>
    {
    }
}