namespace ic_tienda_bussines.Store.repositories {
    public interface IStoreRepository {
        
    }
}