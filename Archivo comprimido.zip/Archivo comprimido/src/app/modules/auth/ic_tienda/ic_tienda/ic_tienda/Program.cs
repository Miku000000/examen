using ic_tienda_bussines.Auth.repositories;
using ic_tienda_bussines.Auth.services;
using ic_tienda_bussines.Store.repositories;
using ic_tienda_bussines.Store.services;
using ic_tienda_data.Auth.repositories;
using ic_tienda_data.Auth.services;
using ic_tienda_data.Store.repositories;
using ic_tienda_data.Store.services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

string connStr = builder.Configuration
    .GetValue<string>("ConnectionStrings:IcTiendaDb");

builder.Services.AddDbContext<ic_tienda_data.sources.BaseDeDatos.IcTiendaDbContext>(
    // Connect to SqlServer
    //(config) => config.UseSqlServer(connStr, b => b.MigrationsAssembly("ic_tienda_presentacion"))
    // connect to sqlite database
    (config) => config.UseSqlite(
        builder.Configuration.GetConnectionString("IcLocalDb"),
        b => b.MigrationsAssembly("ic_tienda_presentacion")
    )
);

builder.Services.AddCors(
    (conf) => conf.AddDefaultPolicy( policy => 
        policy.AllowAnyHeader()
            .AllowAnyMethod()
            //.AllowAnyOrigin()
            //.WithMethods("GET,PUT")
            .WithOrigins("http://localhost:4200", "http://localhost:49484")
    )
);

// Inyeccion de dependencias
// services
builder.Services.AddScoped<IRolService, RolServiceDbImpl>();
builder.Services.AddScoped<IAppUserService, AppUserDbImpl>();
builder.Services.AddScoped<IAuthenticationService, AuthenticationServiceDbImpl>();
builder.Services.AddScoped<IBrandService, BrandServiceDbImpl>();
builder.Services.AddScoped<ICategoryService, CategoryServiceDbImpl>();
builder.Services.AddScoped<IProductService, ProductServiceDbImpl>();
// repositories
builder.Services.AddScoped<IAuthRepository, AuthRepository>();
builder.Services.AddScoped<IProductRepository, ProductRepositryImpl>();




var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.UseCors();

app.Run();
