namespace ic_tienda_bussines.Errors {
  public class MessageExeption: Exception {
    public MessageExeption(string message)
        : base(message)
    {
    }
  }
}