﻿using ic_tienda_bussines.Auth.models;
using ic_tienda_bussines.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ic_tienda_bussines.Auth.services
{
    public interface IAppUserService : ICrud<AppUser>
    {
    }
}
