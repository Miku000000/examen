using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using ic_tienda_data.sources.BaseDeDatos.Tables;

namespace ic_tienda_data.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriasController : ControllerBase
    {
        private readonly DbContext _context; // Reemplaza DbContext con tu contexto real.

        public CategoriasController(DbContext context)
        {
            _context = context;
        }

        // GET: api/categorias
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoriaTable>>> GetCategorias()
        {
            return await _context.Set<CategoriaTable>().ToListAsync();
        }

        // POST: api/categorias
        [HttpPost]
        public async Task<ActionResult<CategoriaTable>> CreateCategoria(CategoriaTable categoria)
        {
            _context.Set<CategoriaTable>().Add(categoria);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCategorias), new { id = categoria.id }, categoria);
        }

        // DELETE: api/categorias/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategoria(int id)
        {
            var categoria = await _context.Set<CategoriaTable>().FindAsync(id);
            if (categoria == null)
            {
                return NotFound();
            }

            _context.Set<CategoriaTable>().Remove(categoria);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

