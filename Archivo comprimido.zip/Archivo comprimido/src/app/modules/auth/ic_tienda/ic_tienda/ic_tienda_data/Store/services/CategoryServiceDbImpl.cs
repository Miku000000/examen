using ic_tienda_bussines.Errors;
using ic_tienda_bussines.Store.models;
using ic_tienda_bussines.Store.services;
using ic_tienda_data.sources.BaseDeDatos;
using ic_tienda_data.sources.BaseDeDatos.Tables;
using ic_tienda_data.Store.extentions;
using System.Collections.Generic;
using System.Linq;

namespace ic_tienda_data.Store.services
{
    public class CategoryServiceDbImpl : ICategoryService
    {
        private readonly IcTiendaDbContext _db;

        public CategoryServiceDbImpl(IcTiendaDbContext db)
        {
            _db = db;
        }

        public Category Create(Category entity)
        {
            CategoriaTable categoriaTable = entity.ToTable();
            _db.categorias.Add(categoriaTable);
            int r = _db.SaveChanges();
            if (r == 1)
            {
                entity.Id = categoriaTable.id;
                return entity;
            }
            else
            {
                throw new MessageExeption("No se pudo insertar esta categoría");
            }
        }

        public void Delete(int id)
        {
            CategoriaTable? categoriaTable = _db.categorias.FirstOrDefault(r => r.id == id && r.estado);
            if (categoriaTable == null) throw new MessageExeption("No se encontró la categoría");
            
            categoriaTable.estado = false; // Marcar como inactiva
            int r = _db.SaveChanges();
            if (r != 1) throw new MessageExeption("No se pudo eliminar la categoría");
        }

        public List<Category> GetAll()
        {
            return _db.categorias
                .Where(r => r.estado)
                .Select(rt => rt.ToModel())
                .ToList();
        }

        public Category? GetById(int id)
        {
            CategoriaTable? categoria = _db.categorias
                .FirstOrDefault(r => r.id == id && r.estado);
            return categoria?.ToModel();
        }

        public void Update(int id, Category body)
        {
            CategoriaTable? categoria = _db.categorias
                .FirstOrDefault(r => r.id == id && r.estado);
            if (categoria == null) throw new MessageExeption("No se encontró la categoría");

            categoria.nombre = body.Name;
            categoria.descripcion = body.Description;

            int r = _db.SaveChanges();
            if (r != 1) throw new MessageExeption("No se pudo actualizar la categoría");
        }
    }
}
