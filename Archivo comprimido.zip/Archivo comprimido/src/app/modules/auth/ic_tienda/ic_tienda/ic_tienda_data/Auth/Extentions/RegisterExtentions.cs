using ic_tienda_bussines.Auth.models;
using ic_tienda_data.sources.BaseDeDatos.Tables;

namespace ic_tienda_data.Auth.Transforms
{
  public static class RegisterExtentions {
    public static PersonaTable ToPerson(this AppUserRegister body) {
      return new PersonaTable {
        id = 0,
        nombres = body.Name,
        apellidos = body.LastName,
        tipo_documento = body.DocumentType,
        numero_documento = body.DocumentType,
        telefono = body.LastName,
        estado = true
      };
    }
  }
}