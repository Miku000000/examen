export const environment = {
    backendBaseUrl: "https://api.mitienda.com",
};
