export const environment = {
    backendBaseUrl: "https://localhost:63419",
};
